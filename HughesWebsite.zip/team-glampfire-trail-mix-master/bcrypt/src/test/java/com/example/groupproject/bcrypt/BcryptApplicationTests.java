package com.example.groupproject.bcrypt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcryptApplicationTests {

    @Test
    void contextLoads() {
    }

}
