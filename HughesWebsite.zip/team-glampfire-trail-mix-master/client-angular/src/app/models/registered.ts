export class Registered {
    status: boolean;
}
