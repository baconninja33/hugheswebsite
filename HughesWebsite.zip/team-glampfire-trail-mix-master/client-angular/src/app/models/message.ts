export class Message {
    id: string;
    name: string;
    email: string;
    subject: string;
    message: string;
    read: boolean;
    createDate: string;
    prettyDate: string;
    prettyTime: string;
}
