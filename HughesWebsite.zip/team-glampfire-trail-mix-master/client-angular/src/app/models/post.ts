export class Post {
  id: string;
  title: string;
  content: string;
  createDate: Date;

  constructor() {
    this.title = '';
    this.content = '';
  }

}
